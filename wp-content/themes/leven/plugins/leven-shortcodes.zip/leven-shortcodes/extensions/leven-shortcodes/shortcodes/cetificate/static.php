<?php if (!defined('FW')) die('Forbidden');

wp_enqueue_style(
    'fw-shortcode-certificate',
    plugin_dir_url( __FILE__ ) . 'static/css/styles.css'
);
